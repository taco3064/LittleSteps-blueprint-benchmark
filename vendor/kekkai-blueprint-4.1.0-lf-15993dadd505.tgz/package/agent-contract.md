# Blueprint agent operating discipline

> Shipped with `@kekkai/blueprint`. This is the **generic** half of the
> architecture contract — the same for every project. The **project** half
> (modules, layers, flow order, unit shapes, ownership, naming, playbook) is compiled
> from `blueprint.config.mjs` into the repo's generated handbook; the pointer
> block in your agent context file links both.

## The one-way flow

- `architecture.alias` is the sole canonical source-root alias. Across a layer or
  module boundary, never substitute an `additionalAliases` spelling.
- A layer may import only layers declared **after** it in the blueprint —
  never upstream, never the same layer through the alias inside its current module.
- In Module → Layer → Unit topology, a module may import only itself and modules
  transitively reachable through its `dependsOn` edges. Declaration order grants
  no permission, and the inner layer flow must independently allow the import.
- Same-layer dependencies inside the current module use relative paths, never the alias.
  Across modules, a reachable same-layer dependency uses the alias so its module and
  layer identity remain explicit. In a folder-layout layer, a sibling unit is reachable
  only through its declared entry; deeper paths stay private. Shared code that does not
  belong to either unit moves downward.
- Relative imports stay inside the importer's declared **module and layer/position**.
  They never cross a module boundary. A module-root container may reference another
  direct container file only inside its own module, but reaches layer units through
  the alias so the structural rules can see the dependency.
- Folder-layout units are **entry-only**: import the unit path, never internals
  behind its declared entry.
- Statically resolvable dynamic imports follow the same alias, flow, and unit-entry
  rules. Runtime-dependent targets are an explicit analysis limitation, never proof
  that the import is legal.

## When lint fails

- Fix the **structure** — move the code, or extract a lower layer. The error
  is the architecture speaking, not a formality.
- Never silence a structural rule with `eslint-disable`; never "fix" a
  violation by relocating it to a sibling file the rule does not cover yet.
- Every intentional disable of a *non-structural* rule carries a reason
  (`-- why`), or lint rejects it.
- Treat `warn`-tier results as review entry points: look, then decide —
  don't ignore, don't blindly appease.

## When another tool disagrees

- Third-party lint advice sometimes collides with the blueprint's unit
  shape — e.g. a fast-refresh rule asking you to split `XxxContext` and
  `XxxProvider` into separate files, when the unit shape says a context
  unit exports them together. **The blueprint is the source of truth for
  structure**; the other tool's rule is triage, not a verdict. Keep the
  blueprint shape and disable the conflicting rule locally, with a reason.
- The reverse holds too: never use a third-party suggestion as cover to
  bypass a structural rule.

## What no tool enforces (you are the gate)

- Do not create undeclared architectural folders under the project alias root.
  Every such folder belongs to the declared topology: Layer → Unit by default,
  or Module → Layer → Unit when `architecture.modules` is declared — even as `[]`,
  a module-first runway with no domain module yet. `blueprint inspect` catches this
  after the fact; you prevent it. Its finding directs you to move the code into the
  declared layer (and module) that owns it. When none owns it, a layer-first finding
  asks the owner whether the architecture should change; a module-first finding sends
  owner-requested product work that needs a new domain boundary to the module growth
  protocol in the generated handbook.
  If the architecture has otherwise outgrown the config — layers, rules, thresholds —
  report it and stop. Editing the architecture to fit code you just wrote is how a
  contract stops describing anything.
- Dead code: `npx knip` is the source of truth, not lint. Confirm removal
  candidates before deleting; leave nothing "temporarily kept" without a
  marker the team agreed on.

## Before you commit

- [ ] Imports use the canonical alias across boundaries and pass the module DAG when configured and the one-way layer flow (no upstream layers, local same-layer aliases, or escaping relatives).
- [ ] Statically resolvable dynamic imports pass the same checks; runtime-dependent targets have been reviewed explicitly.
- [ ] New code sits in the right layer and, when configured, module; folder units expose only their entry.
- [ ] No new undeclared folders under the alias root.
- [ ] Names follow the project's conventions (see the handbook).
- [ ] `npx blueprint inspect` (with `--baseline` on brownfield repos) is green.

## Where the project specifics live

- `blueprint.config.mjs` — the single source of truth.
- The generated handbook (default `docs/architecture-handbook.md`) — modules,
  layers, responsibilities, unit shapes, ownership, naming, principles, playbook.
- `.blueprint-baseline.json` — accepted debt on brownfield repos; the ratchet
  fails only on **new** findings.
- `.blueprint-lifecycle.json` — the lifecycle checkpoint and Blueprint ownership records
  `blueprint upgrade` and `blueprint remove` read; never edit it by hand.

## Upgrading or removing Blueprint

- **"Upgrade Blueprint to the latest version"** — run `npx @kekkai/blueprint@latest upgrade --dry-run`, then `npx @kekkai/blueprint@latest upgrade`. The running release is the only target. When it writes `blueprint-upgrade.md`, do exactly those operations, record each with `npx blueprint upgrade --complete <operation-id>`, and re-run `npx blueprint upgrade` until it reports the upgrade complete. A bare `npm update` skips migrations and verification; never apply release notes or a hand-made migration.
- **"Remove Blueprint from this project"** — run `npx blueprint remove --dry-run`, resolve every conflict it lists, then run `npx blueprint remove`. It reverses only what it can prove Blueprint owns and uninstalls `@kekkai/blueprint` last; never uninstall the package first or delete shared files by hand, and review everything it reports as kept.
